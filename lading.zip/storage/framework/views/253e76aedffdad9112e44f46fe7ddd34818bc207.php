<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section class="mt-8">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div class="col-span-1 ">
                <div class="mx-5 pt-3 lg:pt-16">
                    <h1 class="xl:mx-10 font-bold text-4xl ">
                        Abre tu tienda en línea y potencia tu empredimiento
                    </h1>
                    <p class="py-7 xl:mx-10 font-semibold text-xl">
                        Súmate a la nueva comunidad de emprededores con productos autenticos y originales
                    </p>
                    <div class="my-3 flex justify-center md:justify-start items-center">
                        <a class="px-4 py-2 xl:mx-10 bg-red-400 rounded text-lg font-bold text-white hover:text-black" href="<?php echo e(route('enrolled')); ?>">Únete</a>
                    </div>
                    
                </div>
            </div>
            <div class="">
                <figure>
                    <img class="-my-8 h-1/3 w-full object-cover" src="<?php echo e(asset('vector/Ecommerce/PNG/DrawKit Vector Illustration Ecommerce & Online Shopping (4).png')); ?>" alt="">
                </figure>
            </div>
        </div>
    </section>

    <section id="herramientas" class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 mt-24">
        <h1 class="text-center text-4xl font-bold my-20">Herramientas simples y poderosas</h1>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            <div class="col-span-1">
                <article class="mx-4">
                    <div class="flex justify-center">
                        <div class="flex justify-center items-center h-24 w-24 rounded-full bg-red-400">
                            <i class="fas fa-star text-2xl text-yellow-400"></i>
                            <h1 class="text-xl font-bold ml-2 items-center">4.5</h1>
                        </div>
                    </div>
                    
                    <h2 class="text-center font-bold text-lg">Recibe comentarios y calificacion de tu producto</h2>
                    <p class="text-center text-sm text-gray-600">Decubre las experiencias que tus seguidores tienen con tus creaciones y aprende qué es lo que mas les gusta</p>
                </article>
            </div>
            <div class="col-span-1">
                <article class="mx-4">
                    <div class="flex justify-center">
                        <div class="flex justify-center items-center h-24 w-24 rounded-full bg-red-400">
                            <i class="fas fa-box-open text-4xl text-block"></i>
                        </div>
                    </div>
                    
                    <h2 class="text-center font-bold text-lg mt-0.5">Gestiona y comparte tu stock</h2>
                    <p class="text-center font-semibold text-sm text-gray-600">Registra tu stock y deja que se actualice solo con cada venta. Tus seguidores sabrán cuanto tienes en todo momento</p>
                </article>
            </div>
            <div class="col-span-1">
                <article class="mx-4">
                    <div class="flex justify-center">
                        <div class="flex justify-center items-center h-24 w-24 rounded-full bg-red-400">
                            <i class="fas fa-star text-4xl text-block"></i>
                        </div>
                    </div>
                    
                    <h2 class="text-center font-bold text-lg my-0.5">Exposición personalizada</h2>
                    <p class="text-center font-semibold text-sm text-gray-600">Tus creaciones son recomendadas especialmente a aquellos interesados en tu estilo</p>
                </article>
            </div>
            <div class="col-span-1">
                <article class="mx-4">
                    <div class="flex justify-center">
                        <div class="flex justify-center items-center h-24 w-24 rounded-full bg-red-400">
                            <i class="fas fa-chart-line text-4xl text-block"></i>
                        </div>
                    </div>
                    
                    <h2 class="text-center font-bold text-lg mt-0.5">Obten reporte de tus ventas</h2>
                    <p class="text-center font-semibold text-sm text-gray-600">Lleva un registro de tus ventas, perfecto para tomar mejores desiciones y evolucionar tu proyecto</p>
                </article>
            </div>
            <div class="col-span-1">
                <article class="mx-4">
                    <div class="flex justify-center">
                        <div class="flex justify-center items-center h-24 w-24 rounded-full bg-red-400">
                            <i class="fas fa-tag text-4xl text-block"></i>
                        </div>
                    </div>
                    
                    <h2 class="text-center font-bold text-lg mt-0.5">Crea distinto y vende distinto</h2>
                    <p class="text-center font-semibold text-sm text-gray-600">Crea tus codigos y promos personalizadas para que la comunidad disfrute de tus productos al maximo</p>
                </article>
            </div>
            <div class="col-span-1">
                <article class="mx-4">
                    <div class="flex justify-center">
                        <div class="flex justify-center items-center h-24 w-24 rounded-full bg-red-400">
                            <i class="fas fa-clock text-4xl text-block"></i>
                        </div>
                    </div>
                    
                    <h2 class="text-center font-bold text-lg mt-0.5">Organiza tu tiempo</h2>
                    <p class="text-center font-semibold text-sm text-gray-600">A diferencia de las redes, pasa menos tiempo atrapado en el DM y más tiempo creando. 
                        Controla tu empredimiento en un solo lugar</p>
                </article>
            </div>
        </div>
    </section>

    <section id="beneficios" class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 my-24">
        <h1 class="text-center text-4xl font-bold my-20">Beneficios</h1>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-2 md:gap-6">
            <div class="col-span-1">
                <div class="mx-5 pt-3 lg:pt-16">
                    <h1 class="xl:mx-10 font-bold text-4xl ">
                       Tu propia tienda virtual en minutos
                    </h1>
                    <p class="py-7 xl:mx-10 text-sm md:text-base lg:text-lg">
                        Tu perfil propio, tu catálogo, tu galeria, tu propuesta, tus promos, tus reviews, tus favoritos, tu comunidad.
                        Esto y muchos beneficios más para que plasmes la esencia de tu proyecto como siempre quisiste.
                    </p>
                </div>
            </div>
            <div class="col-span-1">
                <figure>
                    <img class="h-1/2" src="<?php echo e(asset('vector/Ecommerce/PNG/DrawKit Vector Illustration Ecommerce & Online Shopping (15).png')); ?>" alt="" srcset="">
                </figure>
            </div>

            <div class="col-span-1 order-2 md:order-1">
                <figure>
                    <img class="h-1/2" src="<?php echo e(asset('vector/Ecommerce/PNG/DrawKit Vector Illustration Ecommerce & Online Shopping (6).png')); ?>" alt="" srcset="">
                </figure>
            </div>
            <div class="col-span-1 order-1 md:order-2">
                <div class="mx-5 pt-3 lg:pt-16">
                    <h1 class="xl:mx-10 font-bold text-4xl ">
                       Vende y vende sin estar presente
                    </h1>
                    <p class="py-7 xl:mx-10 text-sm md:text-base lg:text-lg">
                        Tu perfil propio, tu catálogo, tu galeria, tu propuesta, tus promos, tus reviews, tus favoritos, tu comunidad.
                        Esto y muchos beneficios más para que plasmes la esencia de tu proyecto como siempre quisiste.
                    </p>
                </div>
            </div>

            <div class="col-span-1 order-3">
                <div class="mx-5 pt-3 lg:pt-16">
                    <h1 class="xl:mx-10 font-bold text-4xl ">
                       Tu producto no pasa desapercibido
                    </h1>
                    <p class="py-7 xl:mx-10 text-sm md:text-base lg:text-lg">
                        Tus creaciones no pasan desapercibidas gracias a que te buscan mediante categorias, filtros, nombre del producto,
                        recomendaciones y mucho más. Llega a todo tu publico objetivo y expandelo
                    </p>
                </div>
            </div>
            <div class="col-span-1 order-4">
                <figure>
                    <img class="h-1/2" src="<?php echo e(asset('vector/Ecommerce/PNG/DrawKit Vector Illustration Ecommerce & Online Shopping (3).png')); ?>" alt="" srcset="">
                </figure>
            </div>

            <div class="col-span-1 order-6 md:order-5">
                <figure>
                    <img class="h-1/2" src="<?php echo e(asset('vector/Ecommerce/PNG/DrawKit Vector Illustration Ecommerce & Online Shopping (13).png')); ?>" alt="" srcset="">
                </figure>
            </div>
            <div class="col-span-1 order-5 md:order-6">
                <div class="mx-5 pt-3 lg:pt-16">
                    <h1 class="xl:mx-10 font-bold text-4xl ">
                       Acepta todos los medios de pago
                    </h1>
                    <p class="py-7 xl:mx-10 text-sm md:text-base lg:text-lg">
                        Cobra sin restricciones y al instante. Ya no te preocupes por coordinar cada pago con tus clientes, ahora pueden
                        usar debito y credito de cualquier banco protegidos por cualquier la maxima seguridad.
                    </p>
                </div>
            </div>

            <div class="col-span-1 order-7">
                <div class="mx-5 pt-3 lg:pt-16">
                    <h1 class="xl:mx-10 font-bold text-4xl ">
                       Ordena tus pedidos
                    </h1>
                    <p class="py-7 xl:mx-10 text-sm md:text-base lg:text-lg">
                        Historial a detalle de todos tus pedidos. Planifica tus envios y actualiza su estado de manera fácil
                        y efectiva. Además, tus clientes ven sus órdenes para darles toda la confianza y tranquilidad.
                    </p>
                </div>
            </div>
            <div class="col-span-1 order-8">
                <figure>
                    <img class="h-1/2" src="<?php echo e(asset('vector/Ecommerce/PNG/DrawKit Vector Illustration Ecommerce & Online Shopping (20).png')); ?>" alt="" srcset="">
                </figure>
            </div>
        </div>
    </section>

    <section id="ventas" class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 my-24">
        <h1 class="text-center text-4xl font-bold my-20">¿Qué puedes vender aquí?</h1>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div class="border border-gray-400 overflow-hidden rounded">
                <div class="grid grid-cols-2">
                    <img class="w-full h-32" src="<?php echo e(asset("img/1.jpg")); ?>">
                    <img class="w-full h-32" src="<?php echo e(asset("img/2.jpg")); ?>">
                    <img class="w-full h-32" src="<?php echo e(asset("img/3.jpg")); ?>">
                    <img class="w-full h-32" src="<?php echo e(asset("img/4.jpg")); ?>">
                    </div>
                <article class="py-4">
                    <h1 class="text-center font-bold">Productos hechos a manos</h1>  
                </article>
            </div>

            <div class="border border-gray-400 overflow-hidden rounded">
                <div class="grid grid-cols-2">
                    <img class="w-full h-32" src="<?php echo e(asset("img/1.jpg")); ?>">
                    <img class="w-full h-32" src="<?php echo e(asset("img/2.jpg")); ?>">
                    <img class="w-full h-32" src="<?php echo e(asset("img/3.jpg")); ?>">
                    <img class="w-full h-32" src="<?php echo e(asset("img/4.jpg")); ?>">
                    </div>
                <article class="py-4">
                    <h1 class="text-center font-bold">Moda</h1>  
                </article>
            </div>

            <div class="border border-gray-400 overflow-hidden rounded">
                <div class="grid grid-cols-2">
                    <img class="w-full h-32" src="<?php echo e(asset("img/1.jpg")); ?>">
                    <img class="w-full h-32" src="<?php echo e(asset("img/2.jpg")); ?>">
                    <img class="w-full h-32" src="<?php echo e(asset("img/3.jpg")); ?>">
                    <img class="w-full h-32" src="<?php echo e(asset("img/4.jpg")); ?>">
                    </div>
                <article class="py-4">
                    <h1 class="text-center font-bold">Arte</h1>  
                </article>
            </div>

        </div>
    </section>

    <section id="unete" class="my-20">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 ">
            <div class="col-span-1 ">
                <div class="mx-5 pt-3 lg:pt-16">
                    <h1 class="xl:mx-10 font-bold text-4xl ">
                        ¿Suena Bien?
                    </h1>
                    <p class="py-7 xl:mx-10 font-semibold text-xl">
                        Miles de compradores no pueden esperar a ver que tiene que tienen emprededores
                        creativos como tú!
                    </p>
                    <div class="my-3 flex justify-center md:justify-start items-center">
                        <a class="px-4 py-2 xl:mx-10 bg-red-400 rounded text-lg font-bold text-white hover:text-black" href="<?php echo e(route('enrolled')); ?>">Únete</a>
                    </div>            
                </div>
            </div>
            <div class="">
                <figure>
                    <img class="-my-8 h-1/3 w-full object-cover" src="<?php echo e(asset('vector/Ecommerce/PNG/DrawKit Vector Illustration Ecommerce & Online Shopping (8).png')); ?>" alt="">
                </figure>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\lading\resources\views/welcome.blade.php ENDPATH**/ ?>