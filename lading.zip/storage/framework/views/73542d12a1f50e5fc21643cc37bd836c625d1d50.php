<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 my-16">
        <h1 class="text-red-400 text-5xl font-extrabold text-center">¿Te interesa la idea?</h1>
        <p class="text-gray-500 mx-5 font-bold text-2xl my-7">
            Te inivitamos a ser de los primeros en formar parte de este marketplace exclusivo para la
            emprendedores, déjanos tu info para contactarte :)
        </p>
        <div class="grid grid-cols-1 md:grid-cols-2">
            <div class="col-span-1">
                <form action="<?php echo e(route('inscription')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mx-4 mt-6">
                        <label class="block text-gray-700 font-bold ml-5" for="name">Nombres</label>
                        <input class="w-full rounded border border-gray-400 py-3" name="name" type="text" placeholder="Nombres y Apellidos">
                    </div>

                    <div class="mx-4 mt-6">
                        <label class="block text-gray-700 font-bold ml-5" for="email">Email</label>
                        <input class="w-full rounded border border-gray-400 py-3" name="email" type="text" placeholder="Correo Electronico">
                    </div>

                    <div class="mx-4 mt-6">
                        <label class="block text-gray-700 font-bold ml-5" for="company">Nombre de tu empredimiento</label>
                        <input class="w-full rounded border border-gray-400 py-3" name="company" type="text" placeholder="Nombre de tu empredimiento">
                    </div>

                    <div class="mx-4 mt-3">
                        <textarea class="w-full rounded border border-gray-400" rows="3" name="description" type="text" placeholder="Cuentanos de tu empredimiento"></textarea>
                    </div>

                    <div class="mx-4 mt-3">
                        <label class="block text-gray-700 font-bold ml-5" for="network">Comparte las redes de tu empredimiento</label>
                        <input class="w-full rounded border border-gray-400 py-3" name="network" type="text" placeholder="Perfil de IG, FB o Tik Tok">
                    </div>

                    <div class="mx-4 mt-6">
                        <button class="block w-full text-cente text-white p-4 rounded bg-red-400" type="submit">Enviar</button>
                    </div>
                </form>
            </div>

            <div class="hidden lg:flex">
                <figure>
                    <img src="<?php echo e(asset("vector/Ecommerce/PNG/friends.png")); ?>" alt="">
                </figure>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\lading\resources\views/users/index.blade.php ENDPATH**/ ?>